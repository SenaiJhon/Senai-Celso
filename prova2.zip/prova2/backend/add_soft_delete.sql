-- Script para adicionar suporte a Soft Delete na tabela PRODUTO
-- Execute este script no MySQL para adicionar a coluna 'ativo' se ela não existir

USE saep_db;

-- Adiciona a coluna 'ativo' à tabela PRODUTO se ela não existir
-- Por padrão, todos os produtos existentes serão marcados como ativos (1)
ALTER TABLE PRODUTO 
ADD COLUMN IF NOT EXISTS ativo TINYINT(1) DEFAULT 1 NOT NULL 
COMMENT 'Indica se o produto está ativo (1) ou foi excluído logicamente (0)';

-- Atualiza todos os produtos existentes para ficarem ativos
UPDATE PRODUTO SET ativo = 1 WHERE ativo IS NULL;

-- Verifica a estrutura da tabela
DESCRIBE PRODUTO;

SELECT 'Coluna ativo adicionada com sucesso!' AS Resultado;
